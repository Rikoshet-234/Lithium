#ifndef OPJ_CONFIG_H
#define OPJ_CONFIG_H

#ifndef _MSC_VER
#define OPJ_HAVE_STDINT_H
#define OPJ_HAVE_INTTYPES_H
#endif

#endif /* OPJ_CONFIG_H */
